CREATE DATABASE IF NOT EXISTS `dbecas`;

USE `dbecas`;

SET FOREIGN_KEY_CHECKS=false;

DROP TABLE IF EXISTS `becas`;

CREATE TABLE `becas` (
  `id_becas` int(11) NOT NULL AUTO_INCREMENT,
  `id_detalle` int(11) NOT NULL,
  `id_patrocinador` int(11) NOT NULL,
  `monto` double(6,2) NOT NULL,
  `periodo_pago` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ini_beca` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_becas`),
  UNIQUE KEY `id_detalle` (`id_detalle`),
  UNIQUE KEY `id_patrocinador` (`id_patrocinador`),
  CONSTRAINT `becas_ibfk_1` FOREIGN KEY (`id_detalle`) REFERENCES `detalle_solicitud` (`id_detalle`),
  CONSTRAINT `becas_ibfk_2` FOREIGN KEY (`id_patrocinador`) REFERENCES `patrocinadores` (`id_patrocinador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `becas` VALUES("1","1","2","350.00","mensual","16-05-18");
INSERT INTO `becas` VALUES("2","2","1","500.00","bimestral","");



DROP TABLE IF EXISTS `casos`;

CREATE TABLE `casos` (
  `id_caso` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `id_cita` int(11) NOT NULL,
  PRIMARY KEY (`id_caso`),
  UNIQUE KEY `id_cita` (`id_cita`),
  CONSTRAINT `casos_ibfk_1` FOREIGN KEY (`id_cita`) REFERENCES `citas` (`id_cita`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `casos` VALUES("1","Jummmmm","15-05-18","2");



DROP TABLE IF EXISTS `citas`;

CREATE TABLE `citas` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `color` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `textColor` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `start` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `end` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `id_detalle` int(11) NOT NULL,
  PRIMARY KEY (`id_cita`),
  UNIQUE KEY `id_detalle` (`id_detalle`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`id_detalle`) REFERENCES `detalle_solicitud` (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `citas` VALUES("1","1","Visita","Visitar el hogar de Raquel","blanco","negro","17-05-18","19-05.18","2");
INSERT INTO `citas` VALUES("2","2","Visita","Visita finalizada","blanco","negro","14-05-18","15-05-18","1");



DROP TABLE IF EXISTS `comentarios`;

CREATE TABLE `comentarios` (
  `id_comentario` int(11) NOT NULL AUTO_INCREMENT,
  `comentario` varchar(350) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` varchar(11) COLLATE utf8_spanish_ci NOT NULL,
  `id_becas` int(11) NOT NULL,
  PRIMARY KEY (`id_comentario`),
  UNIQUE KEY `id_becas` (`id_becas`),
  CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`id_becas`) REFERENCES `becas` (`id_becas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `comentarios` VALUES("1","Excelente","18-05-18","1");



DROP TABLE IF EXISTS `detalle_solicitud`;

CREATE TABLE `detalle_solicitud` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_estado` int(11) NOT NULL,
  `id_solicitud` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  UNIQUE KEY `id_solicitud` (`id_solicitud`),
  UNIQUE KEY `id_estado` (`id_estado`),
  CONSTRAINT `detalle_solicitud_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estado_solicitud` (`id_estado`),
  CONSTRAINT `detalle_solicitud_ibfk_2` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud` (`id_solicitud`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `detalle_solicitud` VALUES("1","2","1");
INSERT INTO `detalle_solicitud` VALUES("2","3","2");



DROP TABLE IF EXISTS `estado_solicitud`;

CREATE TABLE `estado_solicitud` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `estado_solicitud` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `estado_solicitud` VALUES("1","Rechazada");
INSERT INTO `estado_solicitud` VALUES("2","Aceptada");
INSERT INTO `estado_solicitud` VALUES("3","Procesando");



DROP TABLE IF EXISTS `estudiantes`;

CREATE TABLE `estudiantes` (
  `id_estudiante` int(11) NOT NULL AUTO_INCREMENT,
  `primer_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `segundo_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `primer_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `segundo_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `contraseña` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `n_carnet` int(8) NOT NULL,
  `grado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `especialidad` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_estudiante`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `estudiantes` VALUES("1","Raquel","Alexandra","Ramos","Perez","raquelramos","1234567","20132176","1 Año","Arquitectura");
INSERT INTO `estudiantes` VALUES("2","Alexander","Gilberto","Corleto","Rivera","crush","123456","20137643","1","Informatica");



DROP TABLE IF EXISTS `familiares_estudiante`;

CREATE TABLE `familiares_estudiante` (
  `id_fam_estudiante` int(11) NOT NULL AUTO_INCREMENT,
  `depende` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `grado` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `institucion` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuota` double(6,2) DEFAULT NULL,
  PRIMARY KEY (`id_fam_estudiante`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `familiares_estudiante` VALUES("1","Si","8 ","Escuela Republica de España","0.00");
INSERT INTO `familiares_estudiante` VALUES("2","Si","7","Escuela Republica de Perú","0.00");



DROP TABLE IF EXISTS `gastos_mensuales`;

CREATE TABLE `gastos_mensuales` (
  `id_gastos` int(11) NOT NULL AUTO_INCREMENT,
  `alimentacion` double(6,2) NOT NULL,
  `pago_vivienda` double(6,2) NOT NULL,
  `energia_electrica` double(6,2) NOT NULL,
  `agua` double(6,2) NOT NULL,
  `telefono` double(6,2) NOT NULL,
  `vigilancia` double(6,2) DEFAULT NULL,
  `servicio_domestico` double(6,2) DEFAULT NULL,
  `alcadia` double(6,2) NOT NULL,
  `pago_deudas` double(6,2) NOT NULL,
  `cotizacion` double(6,2) NOT NULL,
  `seguro_personal` double(6,2) NOT NULL,
  `seguro_vehiculo` double(6,2) DEFAULT NULL,
  `seguro_inmuebles` double(6,2) DEFAULT NULL,
  `transporte` double(6,2) NOT NULL,
  `gastos_man_vehiculo` double(6,2) DEFAULT NULL,
  `salud` double(6,2) NOT NULL,
  `pagos_asociasiones` double(6,2) DEFAULT NULL,
  `pago_colegiatura` double(6,2) NOT NULL,
  `pago_universidad` double(6,2) DEFAULT NULL,
  `gastos_material_estudios` double(6,2) NOT NULL,
  `impuesto_renta` double(6,2) NOT NULL,
  `iva` double(6,2) NOT NULL,
  `tarjeta_credito` double(6,2) NOT NULL,
  `otros` double(6,2) DEFAULT NULL,
  PRIMARY KEY (`id_gastos`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `gastos_mensuales` VALUES("1","100.00","100.00","20.00","10.00","9999.99",NULL,NULL,"7.50","50.00","100.00","25.00",NULL,NULL,"30.00",NULL,"0.00",NULL,"200.00",NULL,"100.00","10.00","10.00","0.00",NULL);
INSERT INTO `gastos_mensuales` VALUES("2","150.00","0.00","25.00","6.00","9999.99",NULL,NULL,"8.00","100.00","100.00","0.00",NULL,NULL,"40.00",NULL,"0.00","25.00","200.00",NULL,"150.00","14.00","13.00","9999.99",NULL);



DROP TABLE IF EXISTS `genero`;

CREATE TABLE `genero` (
  `id_genero` int(11) NOT NULL AUTO_INCREMENT,
  `genero` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_genero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `genero` VALUES("1","Femenino");
INSERT INTO `genero` VALUES("2","Masculino");



DROP TABLE IF EXISTS `grupo_familiar`;

CREATE TABLE `grupo_familiar` (
  `id_familia` int(11) NOT NULL AUTO_INCREMENT,
  `ingreso_familiar` double(6,2) NOT NULL,
  `id_gastos` int(11) NOT NULL,
  `total_gastos` double(7,2) NOT NULL,
  `id_solicitud` int(11) NOT NULL,
  `id_remesa` int(11) NOT NULL,
  `monto_deuda` double(6,2) DEFAULT NULL,
  PRIMARY KEY (`id_familia`),
  UNIQUE KEY `id_remesa` (`id_remesa`),
  UNIQUE KEY `id_solicitud` (`id_solicitud`),
  UNIQUE KEY `id_gastos` (`id_gastos`),
  CONSTRAINT `grupo_familiar_ibfk_1` FOREIGN KEY (`id_gastos`) REFERENCES `gastos_mensuales` (`id_gastos`),
  CONSTRAINT `grupo_familiar_ibfk_2` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud` (`id_solicitud`),
  CONSTRAINT `grupo_familiar_ibfk_3` FOREIGN KEY (`id_remesa`) REFERENCES `remesas_familiar` (`id_remesa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `grupo_familiar` VALUES("1","700.00","1","500.00","1","1","9999.99");
INSERT INTO `grupo_familiar` VALUES("2","800.00","2","650.00","2","2","9999.99");



DROP TABLE IF EXISTS `historial`;

CREATE TABLE `historial` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_caso` int(11) NOT NULL,
  PRIMARY KEY (`id_historial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;




DROP TABLE IF EXISTS `imagenes_casos`;

CREATE TABLE `imagenes_casos` (
  `id_img_caso` int(11) NOT NULL AUTO_INCREMENT,
  `imagen1` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen2` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen3` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen4` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen5` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen6` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `id_caso` int(11) NOT NULL,
  PRIMARY KEY (`id_img_caso`),
  UNIQUE KEY `id_caso` (`id_caso`),
  CONSTRAINT `imagenes_casos_ibfk_1` FOREIGN KEY (`id_caso`) REFERENCES `casos` (`id_caso`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `imagenes_casos` VALUES("1","casa_1.png","casa_2.png","casa_3.png","casa_4.png","casa_5.png","casa_6.png","1");



DROP TABLE IF EXISTS `imagenes_vehiculo`;

CREATE TABLE `imagenes_vehiculo` (
  `id_img_vehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `imagen1` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen2` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen3` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen4` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_propiedad` int(11) NOT NULL,
  PRIMARY KEY (`id_img_vehiculo`),
  UNIQUE KEY `id_propiedad` (`id_propiedad`),
  CONSTRAINT `imagenes_vehiculo_ibfk_1` FOREIGN KEY (`id_propiedad`) REFERENCES `propiedad` (`id_propiedad`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `imagenes_vehiculo` VALUES("1","toyota_1.png","toyota_2.png","toyota_3.png","toyota_4.png","1");
INSERT INTO `imagenes_vehiculo` VALUES("2","kia_1.png","kia_2.png","kia_3.png","kia_4.png","2");



DROP TABLE IF EXISTS `institucion_proveniente`;

CREATE TABLE `institucion_proveniente` (
  `id_institucion_proveniente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_institucion` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `lugar_institucion` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `cuota_pagaba` double(6,2) NOT NULL,
  `año` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_institucion_proveniente`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `institucion_proveniente` VALUES("1","Escuela República de España","San Salvador","0.00","2017");
INSERT INTO `institucion_proveniente` VALUES("2","Escuela Republica de Perú","San Salvador","0.00","2016");



DROP TABLE IF EXISTS `integrante_familia`;

CREATE TABLE `integrante_familia` (
  `id_integrante` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `parentesco` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_nacimiento` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `profesion_ocupacion` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `lugar_trabajo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tel_trabajo` int(8) NOT NULL,
  `salario` double(6,2) NOT NULL,
  `id_fam_estudiando` int(11) NOT NULL,
  `id_solicitud` int(11) NOT NULL,
  PRIMARY KEY (`id_integrante`),
  UNIQUE KEY `id_solicitud` (`id_solicitud`),
  UNIQUE KEY `id_fam_estudiando` (`id_fam_estudiando`),
  CONSTRAINT `integrante_familia_ibfk_1` FOREIGN KEY (`id_fam_estudiando`) REFERENCES `familiares_estudiante` (`id_fam_estudiante`),
  CONSTRAINT `integrante_familia_ibfk_2` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud` (`id_solicitud`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;




DROP TABLE IF EXISTS `intermedia_propiedad`;

CREATE TABLE `intermedia_propiedad` (
  `id_inter` int(11) NOT NULL AUTO_INCREMENT,
  `id_integrante` int(11) NOT NULL,
  `id_propiedad` int(11) NOT NULL,
  PRIMARY KEY (`id_inter`),
  UNIQUE KEY `id_integrante` (`id_integrante`),
  UNIQUE KEY `id_propiedad` (`id_propiedad`),
  CONSTRAINT `intermedia_propiedad_ibfk_1` FOREIGN KEY (`id_propiedad`) REFERENCES `propiedad` (`id_propiedad`),
  CONSTRAINT `intermedia_propiedad_ibfk_2` FOREIGN KEY (`id_integrante`) REFERENCES `integrante_familia` (`id_integrante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;




DROP TABLE IF EXISTS `pagos`;

CREATE TABLE `pagos` (
  `id_recibo` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_emi_recibo` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `id_becas` int(11) NOT NULL,
  PRIMARY KEY (`id_recibo`),
  UNIQUE KEY `id_becas` (`id_becas`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`id_becas`) REFERENCES `becas` (`id_becas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `pagos` VALUES("1","18-05-18","1");



DROP TABLE IF EXISTS `patrocinadores`;

CREATE TABLE `patrocinadores` (
  `id_patrocinador` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_patro` int(11) NOT NULL,
  `profesion` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `cargo` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre_empresa` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(70) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` int(8) NOT NULL,
  PRIMARY KEY (`id_patrocinador`),
  UNIQUE KEY `id_tipo_patro` (`id_tipo_patro`),
  CONSTRAINT `patrocinadores_ibfk_1` FOREIGN KEY (`id_tipo_patro`) REFERENCES `tipo_patrocinador` (`id_tipo_patro`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `patrocinadores` VALUES("1","1","Licenciado","Rolando","Castro","administrador","Prado","Santa Tecla","12345678");
INSERT INTO `patrocinadores` VALUES("2","2","Ingeniero","Guillermo","Chavez","",NULL,"San Salvador","12345678");



DROP TABLE IF EXISTS `propiedad`;

CREATE TABLE `propiedad` (
  `id_propiedad` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_propiedad` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `cuota_mensual` double(6,2) NOT NULL,
  `valor_casa` double(6,2) NOT NULL,
  `tipo_vehiculo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `año_vehiculo` varchar(4) COLLATE utf8_spanish_ci DEFAULT NULL,
  `valor_vehiculo` double(6,2) DEFAULT NULL,
  `croquis` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_propiedad`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `propiedad` VALUES("1","Alquilando","100.00","9999.99","Toyota","2006","2500.00","croquis.png");
INSERT INTO `propiedad` VALUES("2","Propia","0.00","9999.99","KIA","2005","2000.00","croquis.png");



DROP TABLE IF EXISTS `remesas_familiar`;

CREATE TABLE `remesas_familiar` (
  `id_remesa` int(11) NOT NULL AUTO_INCREMENT,
  `monto` double(6,2) DEFAULT NULL,
  `periodo_recibido` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `benefactor` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_remesa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `remesas_familiar` VALUES("1","300.00","mensual","Alfonso Chávez");
INSERT INTO `remesas_familiar` VALUES("2","200.00","trimestral","Rosario Gonzales");



DROP TABLE IF EXISTS `solicitud`;

CREATE TABLE `solicitud` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(11) NOT NULL,
  `id_genero` int(11) NOT NULL,
  `religion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `encargado` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tel_fijo` int(8) DEFAULT NULL,
  `cel_papa` int(8) DEFAULT NULL,
  `cel_mama` int(8) DEFAULT NULL,
  `cel_hijo` int(8) DEFAULT NULL,
  `fecha_nacimiento` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `estudios_finan` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `id_institucion_proveniente` int(11) NOT NULL,
  PRIMARY KEY (`id_solicitud`),
  UNIQUE KEY `id_institucion_proveniente` (`id_institucion_proveniente`),
  UNIQUE KEY `id_estudiante` (`id_estudiante`),
  UNIQUE KEY `id_genero` (`id_genero`),
  CONSTRAINT `solicitud_ibfk_1` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`),
  CONSTRAINT `solicitud_ibfk_2` FOREIGN KEY (`id_institucion_proveniente`) REFERENCES `institucion_proveniente` (`id_institucion_proveniente`),
  CONSTRAINT `solicitud_ibfk_3` FOREIGN KEY (`id_genero`) REFERENCES `genero` (`id_genero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `solicitud` VALUES("1","2","2","","Patricia Rivera","San Salvador","alex@hotmail.com","22224444","11112222","33334444",NULL,"1-09-98","","2");
INSERT INTO `solicitud` VALUES("2","1","1","Catolica","Xoila Perez","Antiguo Cuscatlan","raquel@hotmail.com","22221111","33332222","44445555","77777777","2005","","1");



DROP TABLE IF EXISTS `tipo_patrocinador`;

CREATE TABLE `tipo_patrocinador` (
  `id_tipo_patro` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_patrocinador` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_tipo_patro`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipo_patrocinador` VALUES("1","empresa");
INSERT INTO `tipo_patrocinador` VALUES("2","indendiente");



DROP TABLE IF EXISTS `tipo_usuario`;

CREATE TABLE `tipo_usuario` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_usuario` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipo_usuario` VALUES("1","administrador");
INSERT INTO `tipo_usuario` VALUES("2","jefe");
INSERT INTO `tipo_usuario` VALUES("3","alumno");
INSERT INTO `tipo_usuario` VALUES("4","empresa");



DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `usuario` varchar(34) COLLATE utf8_spanish_ci NOT NULL,
  `contraseña` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `id_tipo` (`id_tipo`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_usuario` (`id_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuarios` VALUES("3","Yolanda","Pereira","1","yolandapereira","1234567");
INSERT INTO `usuarios` VALUES("4","Alexander","Corleto","3","alexandercorleto","1234567");
